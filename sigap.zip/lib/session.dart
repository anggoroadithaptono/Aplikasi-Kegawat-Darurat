// session.dart



Map<String, dynamic>? currentUser;

