package com.example.sigap

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
